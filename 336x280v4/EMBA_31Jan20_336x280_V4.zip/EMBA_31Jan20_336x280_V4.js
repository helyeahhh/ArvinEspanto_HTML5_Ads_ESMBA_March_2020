(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"EMBA_31Jan20_336x280_V4_atlas_", frames: [[338,127,112,30],[268,309,29,23],[352,191,50,48],[338,159,112,30],[0,282,224,48],[471,0,12,248],[485,0,12,233],[452,127,12,219],[338,191,12,204],[404,191,12,189],[418,191,12,175],[432,191,12,160],[485,235,12,146],[352,241,12,131],[366,241,12,116],[380,241,12,102],[466,250,12,93],[318,282,12,84],[226,309,12,75],[240,309,12,65],[254,309,12,56],[299,309,12,47],[0,332,12,38],[14,332,12,29],[28,332,12,20],[338,68,129,57],[226,282,90,25],[0,0,336,280],[338,0,131,66]]}
];


// symbols:



(lib.CachedBmp_757 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_759 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_758 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_754 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_753 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_752 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_751 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_750 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_749 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_748 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_747 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_746 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_745 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_744 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_743 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_742 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_740 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_739 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_738 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_737 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_736 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_735 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_734 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_733 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_732 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.asdfff = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Asset1 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.EMBA_31Jan20_336x280_V4_1 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.fff = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V4_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fff();
	this.instance.setTransform(-65.5,-33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.5,-33,131,66);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.fff();
	this.instance.setTransform(-65.5,-33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.5,-33,131,66);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.asdfff();
	this.instance.setTransform(-64.5,-28.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.5,-28.5,129,57);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.asdfff();
	this.instance.setTransform(-64.5,-28.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.5,-28.5,129,57);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Asset1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90,25);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_753();
	this.instance.setTransform(7.05,3.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(7.1,3.7,112,24), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_759();
	this.instance.setTransform(92.05,6.4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_758();
	this.instance_1.setTransform(86.8,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_757();
	this.instance_2.setTransform(17.85,4.8,0.5,0.5);

	this.instance_3 = new lib.Path_1();
	this.instance_3.setTransform(55.95,12.05,1,1,0,0,0,63,15.7);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.647)",0,3,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,132,44);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_759();
	this.instance.setTransform(92.05,6.4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_758();
	this.instance_1.setTransform(86.8,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_754();
	this.instance_2.setTransform(17.85,4.8,0.5,0.5);

	this.instance_3 = new lib.Path_1();
	this.instance_3.setTransform(55.95,12.05,1,1,0,0,0,63,15.7);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.647)",0,3,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,132,44);


// stage content:
(lib.EMBA_31Jan20_336x280_V4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_2.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
	}
	this.frame_54 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_1.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
		
		
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(1));

	// learn_more
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(259.25,247.6,1,1,0,0,0,56,12);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.button_1 = new lib.Symbol2();
	this.button_1.setTransform(259.25,247.6,1,1,0,0,0,56,12);
	new cjs.ButtonHelper(this.button_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},49).to({state:[{t:this.button_1}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({_off:true,alpha:1,mode:"independent"},5).wait(1));

	// mask_12 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_1 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_2 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_3 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_4 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_5 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_6 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_7 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_8 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_9 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_10 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_11 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_12 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_13 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_14 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_15 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_16 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_17 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_18 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_19 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_20 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_21 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_22 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_23 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_24 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_25 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_26 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_27 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_28 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_29 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_30 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_31 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_32 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_33 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_34 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_35 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_36 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_37 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_38 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_39 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_40 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_41 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_42 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_43 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_44 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_45 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_46 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_47 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_48 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_49 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_50 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_51 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_52 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_53 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");
	var mask_graphics_54 = new cjs.Graphics().p("ArFFIIAAqPIWLAAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_1,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_2,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_3,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_4,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_5,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_6,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_7,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_8,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_9,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_10,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_11,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_12,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_13,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_14,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_15,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_16,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_17,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_18,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_19,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_20,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_21,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_22,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_23,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_24,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_25,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_26,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_27,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_28,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_29,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_30,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_31,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_32,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_33,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_34,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_35,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_36,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_37,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_38,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_39,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_40,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_41,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_42,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_43,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_44,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_45,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_46,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_47,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_48,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_49,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_50,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_51,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_52,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_53,x:77.575,y:130.425}).wait(1).to({graphics:mask_graphics_54,x:77.575,y:130.425}).wait(1));

	// boardroom
	this.instance_1 = new lib.Tween4("synched",0);
	this.instance_1.setTransform(-59.5,127);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(72.5,129);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},34).to({state:[{t:this.instance_2}]},15).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(34).to({_off:false},0).to({_off:true,x:72.5,y:129},15).wait(6));

	// mask_idn (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AqTEEIAAoHIUnAAIAAIHg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_1,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_2,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_3,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_4,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_5,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_6,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_7,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_8,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_9,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_10,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_11,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_12,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_13,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_14,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_15,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_16,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_17,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_18,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_19,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_20,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_21,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_22,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_23,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_24,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_25,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_26,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_27,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_28,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_29,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_30,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_31,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_32,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_33,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_34,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_35,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_36,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_37,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_38,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_39,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_40,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_41,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_42,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_43,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_44,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_45,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_46,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_47,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_48,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_49,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_50,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_51,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_52,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_53,x:72,y:62.9}).wait(1).to({graphics:mask_1_graphics_54,x:72,y:62.9}).wait(1));

	// big_one
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.setTransform(-71.5,62.5);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween2("synched",0);
	this.instance_4.setTransform(74.5,63.5);

	var maskedShapeInstanceList = [this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},9).to({state:[{t:this.instance_4}]},15).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({_off:true,x:74.5,y:63.5},15).wait(31));

	// executive
	this.button_2 = new lib.Symbol3();
	this.button_2.setTransform(63,194.5,1,1,0,0,0,45,12.5);
	new cjs.ButtonHelper(this.button_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.button_2).wait(55));

	// vertical_bar
	this.instance_5 = new lib.CachedBmp_732();
	this.instance_5.setTransform(0,78.65,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_733();
	this.instance_6.setTransform(0,74.15,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_734();
	this.instance_7.setTransform(0,69.65,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_735();
	this.instance_8.setTransform(0,65.1,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_736();
	this.instance_9.setTransform(0,60.6,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_737();
	this.instance_10.setTransform(0,56.1,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_738();
	this.instance_11.setTransform(0,51.6,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_739();
	this.instance_12.setTransform(0,47.05,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_740();
	this.instance_13.setTransform(0,42.55,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_742();
	this.instance_14.setTransform(0,38.05,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_743();
	this.instance_15.setTransform(0,38.05,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_744();
	this.instance_16.setTransform(0,38.05,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_745();
	this.instance_17.setTransform(0,38.05,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_746();
	this.instance_18.setTransform(0,38.05,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_747();
	this.instance_19.setTransform(0,38.1,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_748();
	this.instance_20.setTransform(0,38.1,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_749();
	this.instance_21.setTransform(0,38.1,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_750();
	this.instance_22.setTransform(0,38.1,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_751();
	this.instance_23.setTransform(0,38.1,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_752();
	this.instance_24.setTransform(0,38.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},15).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).wait(21));

	// main_bg
	this.instance_25 = new lib.EMBA_31Jan20_336x280_V4_1();

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(168,140,168,140);
// library properties:
lib.properties = {
	id: '9B50568C1AF8514FBB9E7624DC7EA3F2',
	width: 336,
	height: 280,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/EMBA_31Jan20_336x280_V4_atlas_.png", id:"EMBA_31Jan20_336x280_V4_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['9B50568C1AF8514FBB9E7624DC7EA3F2'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;