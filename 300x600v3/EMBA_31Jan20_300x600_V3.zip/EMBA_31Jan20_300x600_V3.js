(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"EMBA_31Jan20_300x600_V3_atlas_", frames: [[0,683,271,70],[0,755,263,70],[281,938,47,37],[168,827,82,79],[0,965,177,43],[0,602,367,79],[265,755,14,267],[281,683,14,253],[297,683,14,238],[313,683,14,224],[329,683,14,209],[345,683,14,195],[361,683,14,180],[302,0,14,166],[361,865,14,151],[345,880,14,137],[302,293,14,122],[302,168,14,123],[179,908,14,111],[195,908,14,99],[211,908,14,87],[227,908,14,75],[128,898,14,63],[144,908,14,51],[329,894,14,38],[313,909,14,26],[0,1010,14,14],[0,898,126,65],[0,0,300,600],[0,827,166,69]]}
];


// symbols:



(lib.CachedBmp_621 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_620 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_619 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_618 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_617 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_616 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_615 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_614 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_613 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_612 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_611 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_610 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_609 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_608 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_607 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_606 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_605 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_604 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_603 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_602 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_601 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_600 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_599 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_598 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_597 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_596 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_595 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.elevate300x600 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.EMBA_31Jan20_300x600_V3_1 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.gain300x600 = function() {
	this.initialize(ss["EMBA_31Jan20_300x600_V3_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.elevate300x600();
	this.instance.setTransform(-63,-32.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,-32.5,126,65);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.elevate300x600();
	this.instance.setTransform(-63,-32.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,-32.5,126,65);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.gain300x600();
	this.instance.setTransform(-83,-34.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,-34.5,166,69);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.gain300x600();
	this.instance.setTransform(-83,-34.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,-34.5,166,69);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_621();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_620();
	this.instance_1.setTransform(2,0.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,135.5,35.6);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_616();
	this.instance.setTransform(6.95,3.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(7,3.5,183.5,39.5), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_619();
	this.instance.setTransform(151,10.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_618();
	this.instance_1.setTransform(142.35,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_617();
	this.instance_2.setTransform(30.55,9.2,0.5,0.5);

	this.instance_3 = new lib.Path_1();
	this.instance_3.setTransform(91.75,19.7,1,1,0,0,0,98.7,23.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.647)",0,3,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,203,59);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(91.8,19.7,1,1,0,0,0,91.8,19.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,203,59);


// stage content:
(lib.EMBA_31Jan20_300x600_V3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_2.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
	}
	this.frame_54 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_1.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
		
		
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(1));

	// learn_more
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(150.3,563.6,1,1,0,0,0,91.8,19.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.button_1 = new lib.Symbol2();
	this.button_1.setTransform(150.3,563.6,1,1,0,0,0,91.8,19.7);
	new cjs.ButtonHelper(this.button_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},49).to({state:[{t:this.button_1}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({_off:true,alpha:1,mode:"independent"},5).wait(1));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_1 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_2 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_3 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_4 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_5 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_6 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_7 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_8 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_9 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_10 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_11 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_12 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_13 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_14 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_15 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_16 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_17 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_18 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_19 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_20 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_21 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_22 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_23 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_24 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_25 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_26 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_27 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_28 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_29 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_30 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_31 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_32 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_33 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_34 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_35 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_36 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_37 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_38 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_39 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_40 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_41 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_42 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_43 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_44 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_45 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_46 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_47 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_48 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_49 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_50 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_51 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_52 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_53 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");
	var mask_graphics_54 = new cjs.Graphics().p("AqgFIIAAqPIVBAAIAAKPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_1,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_2,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_3,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_4,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_5,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_6,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_7,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_8,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_9,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_10,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_11,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_12,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_13,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_14,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_15,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_16,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_17,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_18,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_19,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_20,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_21,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_22,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_23,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_24,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_25,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_26,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_27,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_28,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_29,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_30,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_31,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_32,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_33,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_34,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_35,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_36,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_37,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_38,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_39,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_40,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_41,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_42,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_43,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_44,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_45,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_46,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_47,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_48,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_49,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_50,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_51,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_52,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_53,x:74.375,y:249.825}).wait(1).to({graphics:mask_graphics_54,x:74.375,y:249.825}).wait(1));

	// elevate
	this.instance_1 = new lib.Tween9("synched",0);
	this.instance_1.setTransform(-50,249.5);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween10("synched",0);
	this.instance_2.setTransform(75.3,249.5);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},34).to({state:[{t:this.instance_2}]},15).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(34).to({_off:false},0).to({_off:true,x:75.3},15).wait(6));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_3 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_4 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_5 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_6 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_9 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_10 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_11 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_12 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_14 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_15 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_17 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_21 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_22 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_24 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_27 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_28 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_29 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_30 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_32 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_40 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_42 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_43 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_47 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_48 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_49 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_51 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_52 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_53 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Au4FPIAAqdIdxAAIAAKdg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_1,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_2,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_3,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_4,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_5,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_6,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_7,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_8,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_9,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_10,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_11,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_12,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_13,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_14,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_15,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_16,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_17,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_18,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_19,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_20,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_21,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_22,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_23,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_24,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_25,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_26,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_27,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_28,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_29,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_30,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_31,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_32,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_33,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_34,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_35,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_36,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_37,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_38,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_39,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_40,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_41,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_42,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_43,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_44,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_45,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_46,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_47,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_48,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_49,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_50,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_51,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_52,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_53,x:102.425,y:177.525}).wait(1).to({graphics:mask_1_graphics_54,x:102.425,y:177.525}).wait(1));

	// vintage_point
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.setTransform(-84,176.5);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween2("synched",0);
	this.instance_4.setTransform(97.65,177.15);

	var maskedShapeInstanceList = [this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},9).to({state:[{t:this.instance_4}]},15).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({_off:true,x:97.65,y:177.15},15).wait(31));

	// Isolation_Mode
	this.button_2 = new lib.Symbol3();
	this.button_2.setTransform(150.1,506.7,1,1,0,0,0,67.8,17.8);
	new cjs.ButtonHelper(this.button_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.button_2).wait(55));

	// vertical
	this.instance_5 = new lib.CachedBmp_595();
	this.instance_5.setTransform(0,200.95,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_596();
	this.instance_6.setTransform(0,194.9,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_597();
	this.instance_7.setTransform(0,188.85,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_598();
	this.instance_8.setTransform(0,182.8,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_599();
	this.instance_9.setTransform(0,176.75,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_600();
	this.instance_10.setTransform(0,170.75,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_601();
	this.instance_11.setTransform(0,164.7,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_602();
	this.instance_12.setTransform(0,158.65,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_603();
	this.instance_13.setTransform(0,152.6,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_604();
	this.instance_14.setTransform(0,146.55,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_605();
	this.instance_15.setTransform(0,147.05,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_606();
	this.instance_16.setTransform(0,147.05,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_607();
	this.instance_17.setTransform(0,147.05,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_608();
	this.instance_18.setTransform(0,147.05,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_609();
	this.instance_19.setTransform(0,147.05,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_610();
	this.instance_20.setTransform(0,147.05,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_611();
	this.instance_21.setTransform(0,147.05,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_612();
	this.instance_22.setTransform(0,147.05,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_613();
	this.instance_23.setTransform(0,147.05,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_614();
	this.instance_24.setTransform(0,147.05,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_615();
	this.instance_25.setTransform(0,147.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},15).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).wait(21));

	// main_bg
	this.instance_26 = new lib.EMBA_31Jan20_300x600_V3_1();

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,300,150,300);
// library properties:
lib.properties = {
	id: 'F1B9A14A03166D409E34270758583642',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/EMBA_31Jan20_300x600_V3_atlas_.png", id:"EMBA_31Jan20_300x600_V3_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F1B9A14A03166D409E34270758583642'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;