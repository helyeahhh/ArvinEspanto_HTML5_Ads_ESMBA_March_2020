(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"EMBA_31Jan20_336x280_V5_atlas_", frames: [[338,119,112,30],[240,309,29,23],[338,183,50,48],[338,151,112,30],[0,282,224,48],[468,0,12,251],[482,0,12,238],[496,0,12,226],[452,119,12,213],[390,183,12,200],[404,183,12,188],[418,183,12,175],[432,183,12,162],[496,228,12,150],[338,233,12,137],[352,233,12,125],[366,233,12,113],[482,240,12,101],[466,253,12,90],[318,282,12,78],[226,309,12,67],[271,309,12,55],[285,309,12,43],[299,309,12,32],[0,332,12,20],[226,282,90,25],[0,0,336,280],[338,0,128,63],[338,65,121,52]]}
];


// symbols:



(lib.CachedBmp_785 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_787 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_786 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_782 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_781 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_780 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_779 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_778 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_777 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_776 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_775 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_774 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_773 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_772 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_771 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_770 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_768 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_767 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_766 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_765 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_764 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_763 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_762 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_761 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_760 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Asset1 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.EMBA_31Jan20_336x280_V5_1 = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.gg = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.xxx = function() {
	this.initialize(ss["EMBA_31Jan20_336x280_V5_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.xxx();
	this.instance.setTransform(-60.5,-26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.5,-26,121,52);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.xxx();
	this.instance.setTransform(-60.5,-26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.5,-26,121,52);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.gg();
	this.instance.setTransform(-64,-31.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-31.5,128,63);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.gg();
	this.instance.setTransform(-64,-31.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-31.5,128,63);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Asset1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90,25);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_781();
	this.instance.setTransform(7.05,3.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(7.1,3.7,112,24), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_787();
	this.instance.setTransform(92.05,6.4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_786();
	this.instance_1.setTransform(86.8,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_785();
	this.instance_2.setTransform(17.85,4.8,0.5,0.5);

	this.instance_3 = new lib.Path_1();
	this.instance_3.setTransform(55.95,12.05,1,1,0,0,0,63,15.7);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.647)",0,3,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,132,44);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_787();
	this.instance.setTransform(92.05,6.4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_786();
	this.instance_1.setTransform(86.8,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_782();
	this.instance_2.setTransform(17.85,4.8,0.5,0.5);

	this.instance_3 = new lib.Path_1();
	this.instance_3.setTransform(55.95,12.05,1,1,0,0,0,63,15.7);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.647)",0,3,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,132,44);


// stage content:
(lib.EMBA_31Jan20_336x280_V5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_2.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
	}
	this.frame_54 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_1.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
		
		
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(1));

	// learn_more
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(259.25,247.6,1,1,0,0,0,56,12);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.button_1 = new lib.Symbol2();
	this.button_1.setTransform(259.25,247.6,1,1,0,0,0,56,12);
	new cjs.ButtonHelper(this.button_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},49).to({state:[{t:this.button_1}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({_off:true,alpha:1,mode:"independent"},5).wait(1));

	// mask_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_1 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_2 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_3 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_4 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_5 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_6 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_7 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_8 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_9 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_10 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_11 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_12 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_13 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_14 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_15 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_16 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_17 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_18 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_19 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_20 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_21 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_22 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_23 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_24 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_25 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_26 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_27 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_28 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_29 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_30 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_31 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_32 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_33 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_34 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_35 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_36 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_37 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_38 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_39 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_40 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_41 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_42 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_43 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_44 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_45 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_46 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_47 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_48 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_49 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_50 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_51 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_52 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_53 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");
	var mask_graphics_54 = new cjs.Graphics().p("ArHF1IAArpIWPAAIAALpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_1,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_2,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_3,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_4,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_5,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_6,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_7,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_8,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_9,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_10,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_11,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_12,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_13,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_14,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_15,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_16,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_17,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_18,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_19,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_20,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_21,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_22,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_23,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_24,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_25,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_26,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_27,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_28,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_29,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_30,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_31,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_32,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_33,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_34,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_35,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_36,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_37,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_38,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_39,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_40,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_41,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_42,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_43,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_44,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_45,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_46,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_47,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_48,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_49,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_50,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_51,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_52,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_53,x:77.525,y:145.425}).wait(1).to({graphics:mask_graphics_54,x:77.525,y:145.425}).wait(1));

	// future_proof
	this.instance_1 = new lib.Tween7("synched",0);
	this.instance_1.setTransform(-63.5,140);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween8("synched",0);
	this.instance_2.setTransform(71.5,141);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},34).to({state:[{t:this.instance_2}]},15).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(34).to({_off:false},0).to({_off:true,x:71.5,y:141},15).wait(6));

	// mask_idn (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_1 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_2 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_3 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_4 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_5 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_6 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_7 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_8 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_9 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_10 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_11 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_12 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_13 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_14 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_15 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_16 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_17 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_18 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_19 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_20 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_21 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_22 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_23 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_24 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_25 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_26 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_27 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_28 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_29 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_30 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_31 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_32 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_33 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_34 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_35 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_36 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_37 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_38 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_39 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_40 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_41 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_42 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_43 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_44 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_45 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_46 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_47 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_48 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_49 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_50 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_51 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_52 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_53 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");
	var mask_1_graphics_54 = new cjs.Graphics().p("ArZE+IAAp7IW0AAIAAJ7g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_1,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_2,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_3,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_4,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_5,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_6,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_7,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_8,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_9,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_10,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_11,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_12,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_13,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_14,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_15,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_16,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_17,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_18,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_19,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_20,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_21,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_22,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_23,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_24,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_25,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_26,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_27,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_28,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_29,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_30,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_31,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_32,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_33,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_34,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_35,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_36,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_37,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_38,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_39,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_40,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_41,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_42,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_43,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_44,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_45,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_46,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_47,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_48,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_49,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_50,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_51,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_52,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_53,x:79.4,y:76.325}).wait(1).to({graphics:mask_1_graphics_54,x:79.4,y:76.325}).wait(1));

	// to_lead
	this.instance_3 = new lib.Tween5("synched",0);
	this.instance_3.setTransform(-71,74.5);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween6("synched",0);
	this.instance_4.setTransform(76,74.5);

	var maskedShapeInstanceList = [this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},9).to({state:[{t:this.instance_4}]},15).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({_off:true,x:76},15).wait(31));

	// executive
	this.button_2 = new lib.Symbol3();
	this.button_2.setTransform(63,194.5,1,1,0,0,0,45,12.5);
	new cjs.ButtonHelper(this.button_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.button_2).wait(55));

	// vertical_bar
	this.instance_5 = new lib.CachedBmp_760();
	this.instance_5.setTransform(0,95.25,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_761();
	this.instance_6.setTransform(0,89.45,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_762();
	this.instance_7.setTransform(0,83.65,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_763();
	this.instance_8.setTransform(0,77.85,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_764();
	this.instance_9.setTransform(0,72.05,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_765();
	this.instance_10.setTransform(0,66.3,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_766();
	this.instance_11.setTransform(0,60.5,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_767();
	this.instance_12.setTransform(0,54.7,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_768();
	this.instance_13.setTransform(0,48.9,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_770();
	this.instance_14.setTransform(0,43.1,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_771();
	this.instance_15.setTransform(0,43.1,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_772();
	this.instance_16.setTransform(0,43.1,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_773();
	this.instance_17.setTransform(0,43.1,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_774();
	this.instance_18.setTransform(0,43.1,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_775();
	this.instance_19.setTransform(0,43.1,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_776();
	this.instance_20.setTransform(0,43.1,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_777();
	this.instance_21.setTransform(0,43.1,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_778();
	this.instance_22.setTransform(0,43.1,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_779();
	this.instance_23.setTransform(0,43.1,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_780();
	this.instance_24.setTransform(0,43.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_14}]},15).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).wait(21));

	// main_bg
	this.instance_25 = new lib.EMBA_31Jan20_336x280_V5_1();
	this.instance_25.setTransform(0,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(168,141,168,140);
// library properties:
lib.properties = {
	id: 'F58EF7D24DEE084A9DAC38492F114D43',
	width: 336,
	height: 280,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/EMBA_31Jan20_336x280_V5_atlas_.png", id:"EMBA_31Jan20_336x280_V5_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F58EF7D24DEE084A9DAC38492F114D43'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;