(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"EMBA_31Jan20_728x90_V3_atlas_", frames: [[932,0,34,81],[901,45,25,81],[968,0,34,81],[730,45,34,81],[869,45,30,84],[455,92,18,42],[533,92,16,43],[551,92,16,43],[495,92,17,42],[569,92,15,42],[475,92,18,42],[514,92,17,42],[598,92,13,42],[678,92,11,42],[613,92,13,42],[668,92,8,59],[272,92,22,60],[320,92,22,59],[399,92,18,59],[296,92,22,60],[54,92,25,59],[344,92,21,59],[159,92,24,59],[81,92,25,59],[185,92,24,59],[975,83,25,61],[379,92,18,61],[236,92,22,62],[1016,0,8,61],[211,92,23,61],[0,92,25,61],[108,92,24,61],[1016,63,8,61],[27,92,25,61],[134,92,23,62],[628,92,26,20],[928,83,45,43],[766,75,101,27],[730,0,200,43],[1004,0,10,148],[260,92,10,134],[367,92,10,120],[419,92,10,105],[431,92,10,91],[443,92,10,77],[586,92,10,63],[656,92,10,49],[691,92,10,34],[703,92,10,20],[766,45,98,28],[0,0,728,90]]}
];


// symbols:



(lib.CachedBmp_965 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_964 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_962 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_961 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_960 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_959 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_958 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_957 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_956 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_954 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_953 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_952 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_955 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_950 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_949 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_929 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_928 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_927 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_926 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_925 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_924 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_931 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_930 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_921 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_920 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_919 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_918 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_916 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_915 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_917 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_913 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_912 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_911 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_910 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_909 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_885 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_884 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_883 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_882 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_881 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_880 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_879 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_878 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_877 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_876 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_875 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_874 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_873 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_872 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.axsdaxf = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.ffff = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V3_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_965();
	this.instance.setTransform(39.6,-6.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_964();
	this.instance_1.setTransform(21.75,-6.75,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_964();
	this.instance_2.setTransform(3.85,-6.75,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_962();
	this.instance_3.setTransform(-16.95,-6.75,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_961();
	this.instance_4.setTransform(-38.25,-6.75,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_960();
	this.instance_5.setTransform(-56.65,-7.35,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_959();
	this.instance_6.setTransform(43.25,-34.15,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_958();
	this.instance_7.setTransform(32.35,-34.15,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_957();
	this.instance_8.setTransform(21.7,-34.45,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_956();
	this.instance_9.setTransform(11.65,-34.15,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_955();
	this.instance_10.setTransform(-1.45,-34.15,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_954();
	this.instance_11.setTransform(-11.2,-34.15,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_953();
	this.instance_12.setTransform(-21.2,-34.15,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_952();
	this.instance_13.setTransform(-31.1,-34.15,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_955();
	this.instance_14.setTransform(-39.25,-34.15,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_950();
	this.instance_15.setTransform(-47.2,-34.15,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_949();
	this.instance_16.setTransform(-56.45,-34.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.6,-34.4,113.2,69.1);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_965();
	this.instance.setTransform(39.6,-6.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_964();
	this.instance_1.setTransform(21.75,-6.75,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_964();
	this.instance_2.setTransform(3.85,-6.75,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_962();
	this.instance_3.setTransform(-16.95,-6.75,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_961();
	this.instance_4.setTransform(-38.25,-6.75,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_960();
	this.instance_5.setTransform(-56.65,-7.35,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_959();
	this.instance_6.setTransform(43.25,-34.15,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_958();
	this.instance_7.setTransform(32.35,-34.15,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_957();
	this.instance_8.setTransform(21.7,-34.45,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_956();
	this.instance_9.setTransform(11.65,-34.15,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_955();
	this.instance_10.setTransform(-1.45,-34.15,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_954();
	this.instance_11.setTransform(-11.2,-34.15,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_953();
	this.instance_12.setTransform(-21.2,-34.15,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_952();
	this.instance_13.setTransform(-31.1,-34.15,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_955();
	this.instance_14.setTransform(-39.25,-34.15,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_950();
	this.instance_15.setTransform(-47.2,-34.15,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_949();
	this.instance_16.setTransform(-56.45,-34.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.6,-34.4,113.2,69.1);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_931();
	this.instance.setTransform(74.15,4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_930();
	this.instance_1.setTransform(59.2,4,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_929();
	this.instance_2.setTransform(50.65,4,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_928();
	this.instance_3.setTransform(35.6,3.6,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_927();
	this.instance_4.setTransform(21.45,4,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_926();
	this.instance_5.setTransform(1.4,4,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_925();
	this.instance_6.setTransform(-13.65,3.6,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_924();
	this.instance_7.setTransform(-28.65,4,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_931();
	this.instance_8.setTransform(-40.8,4,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_930();
	this.instance_9.setTransform(-55.75,4,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_921();
	this.instance_10.setTransform(-71.15,4,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_920();
	this.instance_11.setTransform(-85,4,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_919();
	this.instance_12.setTransform(72.3,-33.3,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_918();
	this.instance_13.setTransform(58.95,-33.3,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_917();
	this.instance_14.setTransform(42.85,-33.3,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_916();
	this.instance_15.setTransform(27.3,-33.75,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_915();
	this.instance_16.setTransform(18.95,-33.3,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_917();
	this.instance_17.setTransform(2.85,-33.3,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_913();
	this.instance_18.setTransform(-20.4,-33.3,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_912();
	this.instance_19.setTransform(-43.25,-33.3,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_911();
	this.instance_20.setTransform(-52.05,-33.3,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_910();
	this.instance_21.setTransform(-67.95,-33.3,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_909();
	this.instance_22.setTransform(-82,-33.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85,-33.7,169.8,67.30000000000001);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_931();
	this.instance.setTransform(74.15,4,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_930();
	this.instance_1.setTransform(59.2,4,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_929();
	this.instance_2.setTransform(50.65,4,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_928();
	this.instance_3.setTransform(35.6,3.6,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_927();
	this.instance_4.setTransform(21.45,4,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_926();
	this.instance_5.setTransform(1.4,4,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_925();
	this.instance_6.setTransform(-13.65,3.6,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_924();
	this.instance_7.setTransform(-28.65,4,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_931();
	this.instance_8.setTransform(-40.8,4,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_930();
	this.instance_9.setTransform(-55.75,4,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_921();
	this.instance_10.setTransform(-71.15,4,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_920();
	this.instance_11.setTransform(-85,4,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_919();
	this.instance_12.setTransform(72.3,-33.3,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_918();
	this.instance_13.setTransform(58.95,-33.3,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_917();
	this.instance_14.setTransform(42.85,-33.3,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_916();
	this.instance_15.setTransform(27.3,-33.75,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_915();
	this.instance_16.setTransform(18.95,-33.3,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_917();
	this.instance_17.setTransform(2.85,-33.3,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_913();
	this.instance_18.setTransform(-20.4,-33.3,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_912();
	this.instance_19.setTransform(-43.25,-33.3,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_911();
	this.instance_20.setTransform(-52.05,-33.3,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_910();
	this.instance_21.setTransform(-67.95,-33.3,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_909();
	this.instance_22.setTransform(-82,-33.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85,-33.7,169.8,67.30000000000001);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.axsdaxf();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,98,28);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_882();
	this.instance.setTransform(6.95,3.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(7,3.5,100,21.5), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol1();
	this.instance.setTransform(49,14,1,1,0,0,0,49,14);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,98,28);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_885();
	this.instance.setTransform(82.3,5.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_884();
	this.instance_1.setTransform(77.55,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_883();
	this.instance_2.setTransform(15.75,4.05,0.5,0.5);

	this.instance_3 = new lib.Path_1();
	this.instance_3.setTransform(50.05,10.7,1,1,0,0,0,57,14.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.647)",0,3,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,120,41);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol2("synched",0);
	this.instance.setTransform(50,10.7,1,1,0,0,0,50,10.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,120,41);


// stage content:
(lib.EMBA_31Jan20_728x90_V3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_2.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
	}
	this.frame_44 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_3.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
		
		
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(1));

	// learn_more
	this.instance = new lib.Symbol2("synched",0);
	this.instance.setTransform(670,64.8,1,1,0,0,0,50,10.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.button_3 = new lib.Symbol5();
	this.button_3.setTransform(670,64.8,1,1,0,0,0,50,10.7);
	new cjs.ButtonHelper(this.button_3, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},39).to({state:[{t:this.button_3}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).to({_off:true,alpha:1,mode:"independent"},5).wait(1));

	// mask_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_1 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_2 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_3 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_4 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_5 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_6 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_7 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_8 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_9 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_10 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_11 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_12 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_13 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_14 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_15 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_16 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_17 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_18 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_19 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_20 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_21 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_22 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_23 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_24 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_25 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_26 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_27 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_28 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_29 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_30 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_31 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_32 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_33 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_34 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_35 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_36 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_37 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_38 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_39 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_40 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_41 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_42 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_43 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");
	var mask_graphics_44 = new cjs.Graphics().p("ApxF3IAArtITjAAIAALtg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_1,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_2,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_3,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_4,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_5,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_6,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_7,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_8,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_9,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_10,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_11,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_12,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_13,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_14,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_15,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_16,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_17,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_18,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_19,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_20,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_21,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_22,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_23,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_24,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_25,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_26,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_27,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_28,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_29,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_30,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_31,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_32,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_33,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_34,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_35,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_36,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_37,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_38,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_39,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_40,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_41,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_42,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_43,x:390.5,y:46.25}).wait(1).to({graphics:mask_graphics_44,x:390.5,y:46.25}).wait(1));

	// career
	this.instance_1 = new lib.Tween7("synched",0);
	this.instance_1.setTransform(259.4,45.7);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween8("synched",0);
	this.instance_2.setTransform(392.7,46.75);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},24).to({state:[{t:this.instance_2}]},15).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24).to({_off:false},0).to({_off:true,x:392.7,y:46.75},15).wait(6));

	// mask_idn (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AtmFjIAArFIbNAAIAALFg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_1,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_2,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_3,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_4,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_5,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_6,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_7,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_8,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_9,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_10,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_11,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_12,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_13,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_14,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_15,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_16,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_17,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_18,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_19,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_20,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_21,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_22,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_23,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_24,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_25,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_26,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_27,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_28,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_29,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_30,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_31,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_32,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_33,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_34,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_35,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_36,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_37,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_38,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_39,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_40,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_41,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_42,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_43,x:233.2,y:47.225}).wait(1).to({graphics:mask_1_graphics_44,x:233.2,y:47.225}).wait(1));

	// vantage
	this.instance_3 = new lib.Tween5("synched",0);
	this.instance_3.setTransform(419.35,45.3);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween6("synched",0);
	this.instance_4.setTransform(231.05,46.35);

	var maskedShapeInstanceList = [this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},9).to({state:[{t:this.instance_4}]},15).wait(21));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({_off:true,x:231.05,y:46.35},15).wait(21));

	// executive
	this.button_2 = new lib.Symbol4();
	this.button_2.setTransform(669,32,1,1,0,0,0,49,14);
	new cjs.ButtonHelper(this.button_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.button_2).wait(45));

	// vertical_guide
	this.instance_5 = new lib.CachedBmp_872();
	this.instance_5.setTransform(323.05,44.05,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_873();
	this.instance_6.setTransform(323.05,40.15,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_874();
	this.instance_7.setTransform(323.05,36.2,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_875();
	this.instance_8.setTransform(323.05,32.3,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_876();
	this.instance_9.setTransform(323.05,28.35,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_877();
	this.instance_10.setTransform(323.05,24.45,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_878();
	this.instance_11.setTransform(323.05,20.5,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_879();
	this.instance_12.setTransform(323.05,16.6,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_880();
	this.instance_13.setTransform(323.05,12.65,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_881();
	this.instance_14.setTransform(323.05,8.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).wait(36));

	// main_bg
	this.instance_15 = new lib.ffff();

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(45));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,45,368,45.099999999999994);
// library properties:
lib.properties = {
	id: '62AC65D503FFB2449123371BA3540850',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/EMBA_31Jan20_728x90_V3_atlas_.png", id:"EMBA_31Jan20_728x90_V3_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['62AC65D503FFB2449123371BA3540850'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;