(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"EMBA_31Jan20_300x250_V5_atlas_", frames: [[0,252,26,20],[456,45,45,43],[302,152,101,27],[302,0,200,43],[420,45,10,221],[432,45,10,210],[444,45,10,199],[456,90,10,188],[468,90,10,177],[480,90,10,166],[492,90,10,156],[405,152,10,145],[385,181,10,134],[302,206,10,123],[314,206,10,112],[326,206,10,112],[338,206,10,100],[350,206,10,88],[362,206,10,77],[444,246,10,65],[492,248,10,54],[28,252,10,42],[40,252,10,31],[52,252,10,19],[64,252,10,7],[0,0,300,250],[302,181,81,23],[302,105,110,45],[302,45,116,58]]}
];


// symbols:



(lib.CachedBmp_567 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_566 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_565 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_564 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_563 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_562 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_561 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_560 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_559 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_558 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_557 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_556 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_555 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_554 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_553 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_552 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_551 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_550 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_549 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_548 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_547 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_546 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_545 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_544 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_543 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.EMBA_31Jan20_300x250_V5_1 = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.exe = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.futureproof = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.tolead = function() {
	this.initialize(ss["EMBA_31Jan20_300x250_V5_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.futureproof();
	this.instance.setTransform(-55,-22.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55,-22.5,110,45);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.futureproof();
	this.instance.setTransform(-55,-22.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55,-22.5,110,45);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tolead();
	this.instance.setTransform(-58,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58,-29,116,58);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tolead();
	this.instance.setTransform(-58,-29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58,-29,116,58);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.exe();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,81,23);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_564();
	this.instance.setTransform(7.05,3.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(7.1,3.5,100,21.5), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_567();
	this.instance.setTransform(82.25,5.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_566();
	this.instance_1.setTransform(77.55,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_565();
	this.instance_2.setTransform(15.75,4.05,0.5,0.5);

	this.instance_3 = new lib.Path_1();
	this.instance_3.setTransform(50.05,10.7,1,1,0,0,0,57.1,14.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.647)",0,3,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,120,41);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol5("synched",0);
	this.instance.setTransform(50,10.7,1,1,0,0,0,50,10.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,120,41);


// stage content:
(lib.EMBA_31Jan20_300x250_V5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_5.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
	}
	this.frame_54 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_6.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
		
		
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(1));

	// learn_more
	this.instance = new lib.Symbol5("synched",0);
	this.instance.setTransform(231.4,221.9,1,1,0,0,0,50,10.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.button_6 = new lib.Symbol8();
	this.button_6.setTransform(231.4,221.9,1,1,0,0,0,50,10.7);
	new cjs.ButtonHelper(this.button_6, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},49).to({state:[{t:this.button_6}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({_off:true,alpha:1,mode:"independent"},5).wait(1));

	// Layer_7 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_1 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_2 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_3 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_4 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_5 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_6 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_7 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_8 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_9 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_10 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_11 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_12 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_13 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_14 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_15 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_16 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_17 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_18 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_19 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_20 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_21 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_22 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_23 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_24 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_25 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_26 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_27 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_28 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_29 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_30 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_31 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_32 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_33 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_34 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_35 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_36 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_37 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_38 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_39 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_40 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_41 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_42 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_43 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_44 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_45 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_46 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_47 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_48 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_49 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_50 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_51 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_52 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_53 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");
	var mask_graphics_54 = new cjs.Graphics().p("Ay5FUIAAqnMAlzAAAIAAKng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_1,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_2,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_3,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_4,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_5,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_6,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_7,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_8,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_9,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_10,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_11,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_12,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_13,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_14,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_15,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_16,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_17,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_18,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_19,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_20,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_21,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_22,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_23,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_24,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_25,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_26,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_27,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_28,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_29,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_30,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_31,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_32,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_33,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_34,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_35,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_36,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_37,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_38,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_39,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_40,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_41,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_42,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_43,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_44,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_45,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_46,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_47,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_48,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_49,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_50,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_51,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_52,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_53,x:125.925,y:118.125}).wait(1).to({graphics:mask_graphics_54,x:125.925,y:118.125}).wait(1));

	// future_proof
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(-56,125.5);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.setTransform(63,125.5);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},35).to({state:[{t:this.instance_2}]},14).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(35).to({_off:false},0).to({_off:true,x:63},14).wait(6));

	// Layer_6 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AvHJIIAAs6IfAAAIAAM6g");
	var mask_1_graphics_1 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_2 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_3 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_4 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_5 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_6 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_7 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_8 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_9 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_10 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_11 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_12 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_13 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_14 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_15 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_16 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_17 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_18 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_19 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_20 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_21 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_22 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_23 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_24 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_25 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_26 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_27 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_28 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_29 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_30 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_31 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_32 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_33 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_34 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_35 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_36 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_37 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_38 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_39 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_40 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_41 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_42 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_43 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_44 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_45 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_46 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_47 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_48 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_49 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_50 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_51 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_52 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_53 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");
	var mask_1_graphics_54 = new cjs.Graphics().p("AvfGdIAAs5Ie/AAIAAM5g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:101.7,y:58.4074}).wait(1).to({graphics:mask_1_graphics_1,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_2,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_3,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_4,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_5,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_6,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_7,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_8,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_9,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_10,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_11,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_12,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_13,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_14,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_15,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_16,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_17,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_18,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_19,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_20,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_21,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_22,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_23,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_24,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_25,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_26,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_27,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_28,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_29,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_30,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_31,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_32,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_33,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_34,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_35,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_36,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_37,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_38,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_39,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_40,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_41,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_42,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_43,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_44,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_45,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_46,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_47,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_48,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_49,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_50,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_51,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_52,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_53,x:104.175,y:75.475}).wait(1).to({graphics:mask_1_graphics_54,x:104.175,y:75.475}).wait(1));

	// to_lead
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.setTransform(-65,65);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween2("synched",0);
	this.instance_4.setTransform(66,66);

	var maskedShapeInstanceList = [this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},9).to({state:[{t:this.instance_4}]},15).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({_off:true,x:66,y:66},15).wait(31));

	// vertical_bar
	this.instance_5 = new lib.CachedBmp_543();
	this.instance_5.setTransform(0,76.65,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_544();
	this.instance_6.setTransform(0,72.35,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_545();
	this.instance_7.setTransform(0,68.05,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_546();
	this.instance_8.setTransform(0,63.8,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_547();
	this.instance_9.setTransform(0,59.5,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_548();
	this.instance_10.setTransform(0,55.2,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_549();
	this.instance_11.setTransform(0,50.9,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_550();
	this.instance_12.setTransform(0,46.65,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_551();
	this.instance_13.setTransform(0,42.35,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_552();
	this.instance_14.setTransform(0,38.05,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_553();
	this.instance_15.setTransform(0.2,37.8,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_554();
	this.instance_16.setTransform(0.2,37.8,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_555();
	this.instance_17.setTransform(0.2,37.8,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_556();
	this.instance_18.setTransform(0.2,37.8,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_557();
	this.instance_19.setTransform(0.2,37.8,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_558();
	this.instance_20.setTransform(0.2,37.8,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_559();
	this.instance_21.setTransform(0.2,37.8,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_560();
	this.instance_22.setTransform(0.2,37.8,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_561();
	this.instance_23.setTransform(0.2,37.8,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_562();
	this.instance_24.setTransform(0.2,37.8,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_563();
	this.instance_25.setTransform(0.2,37.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},15).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).wait(21));

	// executive
	this.button_5 = new lib.Symbol7();
	this.button_5.setTransform(56.5,174.5,1,1,0,0,0,40.5,11.5);
	new cjs.ButtonHelper(this.button_5, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.button_5).wait(55));

	// main_bg
	this.instance_26 = new lib.EMBA_31Jan20_300x250_V5_1();

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(55));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,125,150,125);
// library properties:
lib.properties = {
	id: '3A6D08C156999845A894E8D86D14DC5A',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/EMBA_31Jan20_300x250_V5_atlas_.png", id:"EMBA_31Jan20_300x250_V5_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['3A6D08C156999845A894E8D86D14DC5A'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;