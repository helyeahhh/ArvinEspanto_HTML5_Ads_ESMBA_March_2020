(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"EMBA_31Jan20_728x90_V2_atlas_", frames: [[932,0,34,81],[901,45,25,81],[928,83,25,81],[968,0,34,81],[730,45,34,81],[869,45,30,84],[410,92,18,42],[485,92,16,43],[503,92,16,43],[466,92,17,42],[551,92,13,42],[1016,64,6,42],[606,92,11,42],[521,92,16,42],[343,92,23,42],[430,92,18,42],[246,92,20,53],[619,92,7,53],[268,92,20,53],[224,92,20,55],[176,92,22,53],[290,92,20,53],[200,92,22,53],[380,92,16,53],[450,92,14,53],[82,92,23,63],[107,92,22,62],[28,92,25,62],[1016,0,8,62],[55,92,25,62],[0,92,26,62],[155,92,19,62],[324,92,17,62],[566,92,26,20],[955,83,45,43],[766,75,101,27],[730,0,200,43],[1004,0,10,149],[131,92,10,134],[143,92,10,120],[312,92,10,106],[368,92,10,92],[398,92,10,77],[539,92,10,63],[594,92,10,49],[628,92,10,34],[640,92,10,20],[766,45,98,28],[0,0,728,90]]}
];


// symbols:



(lib.CachedBmp_871 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_870 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_869 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_868 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_867 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_866 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_865 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_864 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_863 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_862 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_860 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_859 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_858 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_857 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_856 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_855 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_837 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_836 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_835 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_834 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_833 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_831 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_830 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_832 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_828 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_827 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_826 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_825 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_824 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_823 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_822 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_821 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_820 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_801 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_800 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_799 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_798 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_797 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_796 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_795 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_794 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_793 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_792 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_791 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_790 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_789 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_788 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.axsdaxf = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.EMBA_31Jan20_728x90_V2_1 = function() {
	this.initialize(ss["EMBA_31Jan20_728x90_V2_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_871();
	this.instance.setTransform(40,-6.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_870();
	this.instance_1.setTransform(22.15,-6.75,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_869();
	this.instance_2.setTransform(4.25,-6.75,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_868();
	this.instance_3.setTransform(-16.55,-6.75,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_867();
	this.instance_4.setTransform(-37.85,-6.75,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_866();
	this.instance_5.setTransform(-56.25,-7.35,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_865();
	this.instance_6.setTransform(46.85,-34.15,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_864();
	this.instance_7.setTransform(35.95,-34.15,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_863();
	this.instance_8.setTransform(25.3,-34.45,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_862();
	this.instance_9.setTransform(15.25,-34.15,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_862();
	this.instance_10.setTransform(1,-34.15,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_860();
	this.instance_11.setTransform(-6.75,-34.15,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_859();
	this.instance_12.setTransform(-12.8,-34.15,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_858();
	this.instance_13.setTransform(-20.75,-34.15,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_857();
	this.instance_14.setTransform(-31.2,-34.15,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_856();
	this.instance_15.setTransform(-46.05,-34.15,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_855();
	this.instance_16.setTransform(-57.05,-34.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57,-34.4,114,69.1);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_871();
	this.instance.setTransform(40,-6.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_870();
	this.instance_1.setTransform(22.15,-6.75,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_869();
	this.instance_2.setTransform(4.25,-6.75,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_868();
	this.instance_3.setTransform(-16.55,-6.75,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_867();
	this.instance_4.setTransform(-37.85,-6.75,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_866();
	this.instance_5.setTransform(-56.25,-7.35,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_865();
	this.instance_6.setTransform(46.85,-34.15,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_864();
	this.instance_7.setTransform(35.95,-34.15,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_863();
	this.instance_8.setTransform(25.3,-34.45,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_862();
	this.instance_9.setTransform(15.25,-34.15,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_862();
	this.instance_10.setTransform(1,-34.15,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_860();
	this.instance_11.setTransform(-6.75,-34.15,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_859();
	this.instance_12.setTransform(-12.8,-34.15,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_858();
	this.instance_13.setTransform(-20.75,-34.15,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_857();
	this.instance_14.setTransform(-31.2,-34.15,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_856();
	this.instance_15.setTransform(-46.05,-34.15,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_855();
	this.instance_16.setTransform(-57.05,-34.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57,-34.4,114,69.1);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_837();
	this.instance.setTransform(49.2,5.85,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_836();
	this.instance_1.setTransform(41.5,5.85,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_835();
	this.instance_2.setTransform(27.4,5.85,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_834();
	this.instance_3.setTransform(13.95,5.45,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_833();
	this.instance_4.setTransform(0.9,5.85,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_832();
	this.instance_5.setTransform(-10.8,5.85,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_831();
	this.instance_6.setTransform(-24.65,5.85,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_830();
	this.instance_7.setTransform(-38.6,5.85,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_832();
	this.instance_8.setTransform(-49,5.85,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_828();
	this.instance_9.setTransform(-59,5.85,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_827();
	this.instance_10.setTransform(46.2,-32.8,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_826();
	this.instance_11.setTransform(32.35,-32.35,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_825();
	this.instance_12.setTransform(16.65,-32.35,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_824();
	this.instance_13.setTransform(7.7,-32.35,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_823();
	this.instance_14.setTransform(-17,-32.35,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_822();
	this.instance_15.setTransform(-33.15,-32.35,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_821();
	this.instance_16.setTransform(-45.15,-32.35,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_820();
	this.instance_17.setTransform(-56.8,-32.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-32.8,118.2,65.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_837();
	this.instance.setTransform(49.2,5.85,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_836();
	this.instance_1.setTransform(41.5,5.85,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_835();
	this.instance_2.setTransform(27.4,5.85,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_834();
	this.instance_3.setTransform(13.95,5.45,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_833();
	this.instance_4.setTransform(0.9,5.85,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_832();
	this.instance_5.setTransform(-10.8,5.85,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_831();
	this.instance_6.setTransform(-24.65,5.85,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_830();
	this.instance_7.setTransform(-38.6,5.85,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_832();
	this.instance_8.setTransform(-49,5.85,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_828();
	this.instance_9.setTransform(-59,5.85,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_827();
	this.instance_10.setTransform(46.2,-32.8,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_826();
	this.instance_11.setTransform(32.35,-32.35,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_825();
	this.instance_12.setTransform(16.65,-32.35,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_824();
	this.instance_13.setTransform(7.7,-32.35,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_823();
	this.instance_14.setTransform(-17,-32.35,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_822();
	this.instance_15.setTransform(-33.15,-32.35,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_821();
	this.instance_16.setTransform(-45.15,-32.35,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_820();
	this.instance_17.setTransform(-56.8,-32.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-32.8,118.2,65.8);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.axsdaxf();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,98,28);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_798();
	this.instance.setTransform(6.95,3.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(7,3.5,100,21.5), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol1();
	this.instance.setTransform(49,14,1,1,0,0,0,49,14);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,98,28);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_801();
	this.instance.setTransform(82.3,5.7,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_800();
	this.instance_1.setTransform(77.55,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_799();
	this.instance_2.setTransform(15.75,4.05,0.5,0.5);

	this.instance_3 = new lib.Path_1();
	this.instance_3.setTransform(50.05,10.7,1,1,0,0,0,57,14.2);
	this.instance_3.shadow = new cjs.Shadow("rgba(0,0,0,0.647)",0,3,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,120,41);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol2("synched",0);
	this.instance.setTransform(50,10.7,1,1,0,0,0,50,10.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-5,120,41);


// stage content:
(lib.EMBA_31Jan20_728x90_V2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_2.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
	}
	this.frame_44 = function() {
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button_3.on('click', function(){
		/*
		Loads the URL in a new browser window.
		*/
		window.open('#', '_blank');
		});
		
		
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(1));

	// learn_more
	this.instance = new lib.Symbol2("synched",0);
	this.instance.setTransform(670,64.8,1,1,0,0,0,50,10.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.button_3 = new lib.Symbol5();
	this.button_3.setTransform(670,64.8,1,1,0,0,0,50,10.7);
	new cjs.ButtonHelper(this.button_3, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},39).to({state:[{t:this.button_3}]},5).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).to({_off:true,alpha:1,mode:"independent"},5).wait(1));

	// mask_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_1 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_2 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_3 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_4 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_5 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_6 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_7 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_8 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_9 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_10 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_11 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_12 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_13 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_14 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_15 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_16 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_17 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_18 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_19 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_20 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_21 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_22 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_23 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_24 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_25 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_26 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_27 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_28 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_29 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_30 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_31 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_32 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_33 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_34 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_35 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_36 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_37 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_38 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_39 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_40 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_41 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_42 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_43 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");
	var mask_graphics_44 = new cjs.Graphics().p("AqzFkIAArHIVnAAIAALHg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_1,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_2,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_3,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_4,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_5,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_6,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_7,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_8,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_9,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_10,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_11,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_12,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_13,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_14,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_15,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_16,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_17,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_18,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_19,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_20,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_21,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_22,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_23,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_24,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_25,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_26,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_27,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_28,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_29,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_30,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_31,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_32,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_33,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_34,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_35,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_36,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_37,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_38,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_39,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_40,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_41,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_42,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_43,x:377.975,y:47.25}).wait(1).to({graphics:mask_graphics_44,x:377.975,y:47.25}).wait(1));

	// amplify
	this.instance_1 = new lib.Tween4("synched",0);
	this.instance_1.setTransform(241.8,47.95);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(372.85,47.95);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},24).to({state:[{t:this.instance_2}]},15).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24).to({_off:false},0).to({_off:true,x:372.85},15).wait(6));

	// mask_idn (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AqZFYIAAqvIUzAAIAAKvg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_1,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_2,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_3,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_4,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_5,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_6,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_7,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_8,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_9,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_10,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_11,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_12,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_13,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_14,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_15,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_16,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_17,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_18,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_19,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_20,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_21,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_22,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_23,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_24,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_25,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_26,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_27,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_28,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_29,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_30,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_31,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_32,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_33,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_34,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_35,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_36,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_37,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_38,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_39,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_40,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_41,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_42,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_43,x:235.05,y:46.025}).wait(1).to({graphics:mask_1_graphics_44,x:235.05,y:46.025}).wait(1));

	// leadership
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.setTransform(373.95,47.65);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween2("synched",0);
	this.instance_4.setTransform(236.65,47.65);

	var maskedShapeInstanceList = [this.instance_3,this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},9).to({state:[{t:this.instance_4}]},15).wait(21));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({_off:true,x:236.65},15).wait(21));

	// executive
	this.button_2 = new lib.Symbol4();
	this.button_2.setTransform(669,32,1,1,0,0,0,49,14);
	new cjs.ButtonHelper(this.button_2, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get(this.button_2).wait(45));

	// vertical_guide
	this.instance_5 = new lib.CachedBmp_788();
	this.instance_5.setTransform(303.9,44.05,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_789();
	this.instance_6.setTransform(303.9,40.3,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_790();
	this.instance_7.setTransform(303.9,36.55,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_791();
	this.instance_8.setTransform(303.9,32.8,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_792();
	this.instance_9.setTransform(303.9,29.05,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_793();
	this.instance_10.setTransform(303.9,25.25,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_794();
	this.instance_11.setTransform(303.9,21.5,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_795();
	this.instance_12.setTransform(303.9,17.75,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_796();
	this.instance_13.setTransform(303.9,14,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_797();
	this.instance_14.setTransform(303.9,10.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5}]}).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).wait(36));

	// main_bg
	this.instance_15 = new lib.EMBA_31Jan20_728x90_V2_1();
	this.instance_15.setTransform(0,1);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(45));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,46,368,45);
// library properties:
lib.properties = {
	id: '5FC7C0F311B95646838A6C97A15A188E',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/EMBA_31Jan20_728x90_V2_atlas_.png", id:"EMBA_31Jan20_728x90_V2_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5FC7C0F311B95646838A6C97A15A188E'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;